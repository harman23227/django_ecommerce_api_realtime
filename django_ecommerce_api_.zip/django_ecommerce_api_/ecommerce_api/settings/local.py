from .base import *

DEBUG = True
# DATABASES['default']['HOST'] = 'localhost'

CORS_ALLOWED_ORIGINS = [
    "http://localhost:5173",
]
